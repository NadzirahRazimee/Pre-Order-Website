<?php
session_start();
header("Content-Type: application/json");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'seller') {
    echo json_encode(["logged_in" => false]);
    exit();
}

include 'db_dashboard.php';

$query = $pdo->prepare("SELECT store_name FROM users WHERE user_id = ?");
$query->execute([$_SESSION['user_id']]);
$user = $query->fetch(PDO::FETCH_ASSOC);

echo json_encode(["logged_in" => true, "store_name" => $user['store_name'] ?? "Your Store"]);
?>
