<?php
include("db_dashboard.php");

$data = json_decode(file_get_contents("php://input"));
$order_id = $data->order_id;
$new_status = $data->new_status;

$sql = "UPDATE orders SET order_status = '$new_status' WHERE order_id = '$order_id'";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "error" => $conn->error]);
}

$conn->close();
?>
