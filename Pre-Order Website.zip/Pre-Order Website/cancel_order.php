<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}

include 'db_dashboard.php';

$data = json_decode(file_get_contents("php://input"), true);
$order_id = $data['order_id'];
$customer_id = $_SESSION['user_id'];

// Update only if status is Pending
$stmt = $pdo->prepare("UPDATE orders SET order_status = 'Cancelled' WHERE order_id = ? AND customer_id = ? AND order_status = 'Pending'");
$success = $stmt->execute([$order_id, $customer_id]);

echo json_encode(['success' => $success]);
?>
