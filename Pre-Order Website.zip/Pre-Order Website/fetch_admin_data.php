<?php
include 'db_dashboard.php'; 
header('Content-Type: application/json');

try {
    $stmt = $pdo->prepare("SELECT COUNT(*) AS totalUsers FROM users");
    $stmt->execute();
    $totalUsers = $stmt->fetch(PDO::FETCH_ASSOC)['totalUsers'];

    $stmt = $pdo->prepare("SELECT SUM(amount) AS totalSales FROM orders");
    $stmt->execute();
    $totalSales = $stmt->fetch(PDO::FETCH_ASSOC)['totalSales'];

    $salesData = [];
    $stmt = $pdo->prepare("
        SELECT 
            MONTH(order_date) AS month,
            SUM(amount) AS total_sales
        FROM orders
        WHERE YEAR(order_date) = YEAR(CURRENT_DATE())
        GROUP BY MONTH(order_date)
        ORDER BY MONTH(order_date) ASC
    ");
    $stmt->execute();
    $sales = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($sales as $sale) {
        $salesData['months'][] = date('M', strtotime("2023-{$sale['month']}-01"));  // Format month name
        $salesData['values'][] = $sale['total_sales'];
    }

    echo json_encode([
        'totalUsers' => $totalUsers,
        'totalSales' => $totalSales,
        'salesData' => $salesData
    ]);
} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
