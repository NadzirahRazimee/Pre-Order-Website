<?php
include('db_dashboard.php');

$order_id = $_POST['order_id'];
$payment_status = $_POST['payment_status']; 

$query = "UPDATE orders SET status = '$payment_status' WHERE order_id = '$order_id'";
$result = mysqli_query($conn, $query);

if ($result) {
    echo json_encode(['success' => true, 'message' => 'Payment confirmed']);
} else {
    echo json_encode(['success' => false, 'error' => 'Failed to update payment status']);
}
?>
