<?php
session_start();
include 'db_dashboard.php';

if (!isset($_SESSION['customer_id'])) {
    echo json_encode(["status" => "error", "message" => "Not logged in"]);
    exit;
}

$customer_id = $_SESSION['customer_id'];
$item_name = $_POST['item_name'];
$quantity = $_POST['quantity'];
$price = $_POST['price'];
$status = "Pending";

$query = "INSERT INTO orders (customer_id, item_name, quantity, price, status) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("isdis", $customer_id, $item_name, $quantity, $price, $status);

if ($stmt->execute()) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to place order"]);
}
?>
