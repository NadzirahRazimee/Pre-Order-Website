<?php

$host = "localhost";
$user = "root";
$password = "";
$dbname = "onlinewebsite"; 

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Connection failed: " . $conn->connect_error]));
}

$product_id = $_POST['product_id'];
$name = $_POST['name'];
$price = $_POST['price'];
$description = $_POST['description'];
$stock = $_POST['stock'];
$preorder_end = $_POST['preorder_end'];

$imagePath = '';
if (!empty($_FILES['image']['name'])) {
    $uploadDir = "uploads/";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $imageName = basename($_FILES["image"]["name"]);
    $targetFile = $uploadDir . time() . "_" . $imageName;

    if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
        $imagePath = $targetFile;
    } else {
        echo json_encode(["success" => false, "message" => "Image upload failed."]);
        exit;
    }
}

$sql = "UPDATE products SET 
            name = ?, 
            price = ?, 
            description = ?, 
            stock = ?, 
            preorder_end = ?" .
            (!empty($imagePath) ? ", image = ?" : "") . "
        WHERE product_id = ?";

$stmt = $conn->prepare($sql);

if (!empty($imagePath)) {
    $stmt->bind_param("sdsissi", $name, $price, $description, $stock, $preorder_end, $imagePath, $product_id);
} else {
    $stmt->bind_param("sdsisi", $name, $price, $description, $stock, $preorder_end, $product_id);
}

if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["success" => false, "message" => $stmt->error]);
}

$stmt->close();
$conn->close();
?>
