<?php
$host = "localhost";
$dbname = "onlinewebsite";
$username = "root";
$password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["qr_code"])) {
        $seller_id = $_POST["seller_id"];

        // Create uploads folder if not exists
        if (!is_dir("uploads")) {
            mkdir("uploads", 0777, true);
        }

        // Save the QR code image
        $fileName = "qr_" . $seller_id . "_" . time() . ".png";
        $qrPath = "uploads/" . $fileName;
        move_uploaded_file($_FILES["qr_code"]["tmp_name"], $qrPath);

        // Update database
        $stmt = $pdo->prepare("UPDATE users SET qr_code = ? WHERE user_id = ?");
        $stmt->execute([$qrPath, $seller_id]);

        echo json_encode(["success" => true, "qr_code" => $qrPath]);
    } else {
        echo json_encode(["error" => "Invalid request"]);
    }
} catch (PDOException $e) {
    echo json_encode(["error" => "Database error: " . $e->getMessage()]);
}
?>
