<?php
$host = "localhost";
$dbname = "onlinewebsite";
$username = "root";
$password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if (isset($_GET["id"]) && !empty($_GET["id"])) {
        $product_id = $_GET["id"];

        $stmt = $pdo->prepare("SELECT products.*, users.qr_code 
                               FROM products 
                               JOIN users ON products.seller_id = users.user_id 
                               WHERE products.product_id = ?");
        $stmt->execute([$product_id]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($product) {
            echo json_encode($product);
        } else {
            echo json_encode(["error" => "Product not found"]);
        }
    } else {
        echo json_encode(["error" => "Product ID is missing"]);
    }
} catch (PDOException $e) {
    echo json_encode(["error" => "Database error: " . $e->getMessage()]);
}
?>
