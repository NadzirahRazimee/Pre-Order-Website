<?php
session_start();
include 'db_dashboard.php';

header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'] ?? "";
    $password = $_POST['password'] ?? "";

    if (empty($email) || empty($password)) {
        echo json_encode(["success" => false, "message" => "Please enter email and password"]);
        exit();
    }

    $query = "SELECT * FROM users WHERE email = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION["user_id"] = $user["user_id"];
        $_SESSION["username"] = $user["username"];
        $_SESSION["role"] = $user["role"];

        $redirect = ($user["role"] === "seller") ? "Seller.html" : "Home.html";

        echo json_encode(["success" => true, "redirect" => $redirect]);
    } else {
        echo json_encode(["success" => false, "message" => "Invalid email or password"]);
    }
}
?>
