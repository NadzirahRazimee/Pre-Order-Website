<?php 
session_start();
header('Content-Type: application/json');
include 'db_dashboard.php'; 

try {
    $stmt = $pdo->prepare("
        SELECT
            p.name AS product_name,  -- Fetching product name instead of order ID
            u.store_name AS shop_name,
            od.quantity,
            (od.quantity * od.price) AS total_price,
            o.payment_status,
            o.order_status,
            'Online Banking' AS payment_method,  -- Replace if dynamic
            'Customer Address Here' AS customer_address  -- Replace if stored elsewhere
        FROM orders o
        JOIN order_details od ON o.order_id = od.order_id
        JOIN products p ON od.product_id = p.product_id
        JOIN users u ON o.seller_id = u.user_id
        ORDER BY o.order_date DESC
    ");

    $stmt->execute();
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($orders);
} catch (PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>
