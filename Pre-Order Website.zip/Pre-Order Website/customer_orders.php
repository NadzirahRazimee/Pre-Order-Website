<?php
include 'db_dashboard.php';

$sql = "SELECT o.order_id, c.name, c.email, c.phone, o.item_name, o.quantity, o.price, o.order_status 
        FROM orders o 
        JOIN customers c ON o.customer_id = c.id 
        ORDER BY o.created_at DESC";

$result = $conn->query($sql);
?>

<table border="1">
    <tr>
        <th>Order ID</th>
        <th>Customer</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Item</th>
        <th>Quantity</th>
        <th>Price</th>
        <th>Status</th>
    </tr>

    <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row['order_id']; ?></td>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['phone']; ?></td>
            <td><?php echo $row['item_name']; ?></td>
            <td><?php echo $row['quantity']; ?></td>
            <td><?php echo $row['price']; ?></td>
            <td><?php echo $row['order_status']; ?></td>
        </tr>
    <?php } ?>
</table>
