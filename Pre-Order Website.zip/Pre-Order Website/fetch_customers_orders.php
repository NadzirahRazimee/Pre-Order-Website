<?php
session_start();
include 'db_dashboard.php';

if (!isset($_SESSION['seller_id'])) {
    echo json_encode([]);
    exit;
}

$seller_id = $_SESSION['seller_id'];
$query = "SELECT * FROM orders WHERE seller_id = ? ORDER BY created_at DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$result = $stmt->get_result();

$orders = [];
while ($row = $result->fetch_assoc()) {
    $orders[] = $row;
}

echo json_encode($orders);
?>
