<?php
include 'db_dashboard.php';

$email = $_GET['email'];
$query = "SELECT store_name FROM sellers WHERE email = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();

echo json_encode(["store_name" => $data["store_name"] ?? ""]);
?>
