<?php
include 'db_dashboard.php';

$seller_id = $_SESSION['seller_id'];

$query = "SELECT c.customer_id, c.name AS customer_name, c.avatar AS customer_avatar, 
                 m.message AS last_message, m.timestamp,
                 (SELECT COUNT(*) FROM messages WHERE sender_id = c.customer_id AND receiver_id = $seller_id AND is_read = 0) AS unread_count
          FROM customers c
          LEFT JOIN messages m ON c.customer_id = m.sender_id 
          WHERE m.receiver_id = $seller_id
          GROUP BY c.customer_id
          ORDER BY m.timestamp DESC";

$result = mysqli_query($conn, $query);

$chatList = [];

while ($row = mysqli_fetch_assoc($result)) {
    $chatList[] = [
        'customer_id' => $row['customer_id'],
        'customer_name' => $row['customer_name'],
        'customer_avatar' => $row['customer_avatar'] ?: 'default-avatar.png',
        'last_message' => $row['last_message'],
        'timestamp' => $row['timestamp'],
        'unread' => $row['unread_count'] > 0,
        'unread_count' => $row['unread_count']
    ];
}

header('Content-Type: application/json');
echo json_encode($chatList);
?>
