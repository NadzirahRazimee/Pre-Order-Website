<?php
$host = "localhost"; 
$dbname = "onlinewebsite"; 
$username = "root"; 
$password = ""; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die(json_encode(["success" => false, "message" => "Database connection failed: " . $e->getMessage()]));
}

// Fetch all products
$stmt = $pdo->prepare("SELECT product_id, name, description, price, stock, image, preorder_end FROM products ORDER BY created_at DESC");
$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

$sql = "SELECT products.*, GROUP_CONCAT(product_options.option_name) AS options 
        FROM products 
        LEFT JOIN product_options ON products.product_id = product_options.product_id 
        GROUP BY products.product_id";


echo json_encode($products);
?>
