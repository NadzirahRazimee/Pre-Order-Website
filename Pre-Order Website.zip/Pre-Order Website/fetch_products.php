<?php
include 'db_dashboard.php';

$query = "SELECT * FROM products ORDER BY created_at DESC";
$result = $conn->query($query);

$products = [];
while ($row = $result->fetch_assoc()) {
    $products[] = $row;
}

echo json_encode($products);
?>
