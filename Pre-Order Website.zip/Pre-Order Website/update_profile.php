<?php
session_start();
include 'db_dashboard.php';  

$user_id = $_SESSION['user_id'];
$name = $_POST['name'];
$bio = $_POST['bio'];
$gender = $_POST['gender'];
$birthday = $_POST['birthday'];
$phone = $_POST['phone'];

$sql = "UPDATE users SET name=?, bio=?, gender=?, birthday=?, phone=? WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssi", $name, $bio, $gender, $birthday, $phone, $user_id);

if ($stmt->execute()) {
    echo "Profile updated successfully!";
} else {
    echo "Error updating profile.";
}
?>
