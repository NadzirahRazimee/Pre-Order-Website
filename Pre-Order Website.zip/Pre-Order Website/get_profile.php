<?php
include 'db_dashboard.php';
session_start();

$user_id = $_SESSION['user_id']; 

$sql = "SELECT * FROM users WHERE id = $user_id";
$result = mysqli_query($conn, $sql);

if ($row = mysqli_fetch_assoc($result)) {
    echo json_encode($row);
} else {
    echo json_encode(["error" => "User not found"]);
}

mysqli_close($conn);
?>
