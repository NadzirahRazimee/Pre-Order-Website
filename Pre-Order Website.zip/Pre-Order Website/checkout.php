<?php
session_start();
header('Content-Type: application/json');
include 'db_dashboard.php'; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_id = $_POST['product_id'] ?? null;
    $quantity = $_POST['quantity'] ?? 1; 
    $customer_name = $_POST['customer_name'] ?? null;
    $customer_address = $_POST['customer_address'] ?? null;
    $payment_method = $_POST['payment_method'] ?? null;

   
    if ($product_id && $customer_name && $customer_address && $payment_method) {
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("SELECT name, price FROM products WHERE product_id = :product_id");
            $stmt->execute([':product_id' => $product_id]);
            $product = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($product) {
                // Calculate total price (quantity)
                $total_price = $product['price'] * $quantity;

                // Insert order data into the orders.html
                $stmt = $pdo->prepare("INSERT INTO orders (product_id, customer_name, customer_address, payment_method, total_price, order_status, payment_status) VALUES (:product_id, :customer_name, :customer_address, :payment_method, :total_price, :order_status, :payment_status)");
                $stmt->execute([
                    ':product_id' => $product_id,
                    ':customer_name' => $customer_name,
                    ':customer_address' => $customer_address,
                    ':payment_method' => $payment_method,
                    ':total_price' => $total_price,  
                    ':order_status' => 'Pending',  
                    ':payment_status' => ($payment_method == 'Cash on Delivery') ? 'Pending' : 'Paid',  
                ]);

                $order_id = $pdo->lastInsertId();

                $stmt = $pdo->prepare("INSERT INTO order_details (order_id, product_id, quantity, price) VALUES (:order_id, :product_id, :quantity, :price)");
                $stmt->execute([
                    ':order_id' => $order_id,
                    ':product_id' => $product_id,
                    ':quantity' => $quantity,  // Use the quantity provided by the customer
                    ':price' => $product['price'],
                ]);

                $pdo->commit();

                echo json_encode(['success' => true, 'message' => 'Order placed successfully!']);
            } else {
               
                echo json_encode(['error' => 'Product not found']);
            }
        } catch (PDOException $e) {
            
            $pdo->rollBack();
            echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
        }
    } else {
        echo json_encode(['error' => 'Missing required fields']);
    }
} else {
    echo json_encode(['error' => 'Invalid request method']);
}
?>
