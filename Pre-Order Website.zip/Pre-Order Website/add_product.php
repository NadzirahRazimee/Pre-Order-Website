<?php
$host = "localhost";
$dbname = "onlinewebsite";
$username = "root";
$password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $seller_id = $_POST["seller_id"];
        $name = $_POST["name"];
        $price = $_POST["price"];
        $description = $_POST["description"];
        $stock = $_POST["stock"];
        $preorder_end = $_POST["preorder_end"] ?: NULL;
        $options = isset($_POST["options"]) ? json_decode($_POST["options"], true) : [];

        //image upload
        $imagePath = NULL;
        if (isset($_FILES["image"]) && $_FILES["image"]["error"] == 0) {
            $imagePath = "uploads/" . basename($_FILES["image"]["name"]);
            move_uploaded_file($_FILES["image"]["tmp_name"], $imagePath);
        }

        //add product
        $stmt = $pdo->prepare("INSERT INTO products (seller_id, name, description, price, stock, preorder_end, image) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$seller_id, $name, $description, $price, $stock, $preorder_end, $imagePath]);
        $product_id = $pdo->lastInsertId();

        //add options
        if (!empty($options)) {
            $stmt = $pdo->prepare("INSERT INTO product_options (product_id, option_name) VALUES (?, ?)");
            foreach ($options as $option) {
                $stmt->execute([$product_id, $option]);
            }
        }

        echo json_encode(["success" => true]);
    }
} catch (PDOException $e) {
    echo json_encode(["error" => "Database error: " . $e->getMessage()]);
}
?>
