<?php
$conn = new mysqli("localhost", "root", "", "chat_db");
$result = $conn->query("SELECT user_id, username FROM users");
$users = [];
while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}
echo json_encode($users);
?>
