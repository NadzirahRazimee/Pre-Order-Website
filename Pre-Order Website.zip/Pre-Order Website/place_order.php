<?php
session_start();

$host = "localhost";
$dbname = "onlinewebsite";
$username = "root";
$password = "";

header('Content-Type: application/json'); 
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if (!isset($_SESSION['user_id'])) {
        echo json_encode(["success" => false, "error" => "User not logged in."]);
        exit;
    }


    $customer_id = $_SESSION['user_id'];
    $stmt = $pdo->prepare("SELECT * FROM users WHERE user_id = ?");
    $stmt->execute([$customer_id]);
    $user = $stmt->fetch();

    if (!$user) {
        echo json_encode(["success" => false, "error" => "Invalid customer ID."]);
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $product_id = $_POST['product_id'];
        $quantity = $_POST['quantity'];
        $customer_name = $_POST['customer_name'];
        $customer_address = $_POST['customer_address'];
        $payment_method = $_POST['payment_method'];

        // Fetch product to get seller and price
        $stmt = $pdo->prepare("SELECT price, seller_id FROM products WHERE product_id = ?");
        $stmt->execute([$product_id]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($product) {
            $total_price = $product['price'] * $quantity;

            // Insert order
            $stmt = $pdo->prepare("INSERT INTO orders (customer_name, customer_address, customer_id, seller_id, total_price, payment_method, order_status)
                                   VALUES (?, ?, ?, ?, ?, ?, 'Pending')");
            $stmt->execute([
                $customer_name,
                $customer_address,
                $customer_id,
                $product['seller_id'],
                $total_price,
                $payment_method
            ]);

            echo json_encode(["success" => true]);
        } else {
            echo json_encode(["success" => false, "error" => "Product not found."]);
        }
    }
} catch (PDOException $e) {
    echo json_encode(["success" => false, "error" => "Database error: " . $e->getMessage()]);
}
?>
