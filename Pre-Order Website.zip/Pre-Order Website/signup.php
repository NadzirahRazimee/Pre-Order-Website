<?php
session_start();
include 'db_dashboard.php';

header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];
    $store_name = $_POST['store_name'] ?? null; 

    try {
      
        $checkEmail = $pdo->prepare("SELECT user_id FROM users WHERE email = ?");
        $checkEmail->execute([$email]);

        if ($checkEmail->rowCount() > 0) {
           
            $checkAgain = $pdo->query("SELECT COUNT(*) FROM users WHERE email = '$email'")->fetchColumn();
            if ($checkAgain == 0) {
                $pdo->query("ALTER TABLE users AUTO_INCREMENT = 1"); 
            } else {
                echo json_encode(["success" => false, "message" => "Email already exists. Please use another email."]);
                exit();
            }
        }

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        if ($role === "seller") {
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role, store_name) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$username, $email, $hashedPassword, $role, $store_name]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
            $stmt->execute([$username, $email, $hashedPassword, $role]);
        }

        $_SESSION["user_id"] = $pdo->lastInsertId();
        $_SESSION["username"] = $username;
        $_SESSION["role"] = $role;

        $redirect = ($role === "seller") ? "Seller.html" : "Home.html";
        echo json_encode(["success" => true, "redirect" => $redirect]);

    } catch (PDOException $e) {
        echo json_encode(["success" => false, "message" => "Database error: " . $e->getMessage()]);
    }
}
?>
