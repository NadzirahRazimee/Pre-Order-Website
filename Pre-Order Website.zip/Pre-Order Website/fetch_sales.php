<?php
header('Content-Type: application/json');
include 'db_dashboard.php';

$sql = "SELECT DATE(order_date) as date, SUM(total_price) as total_sales 
        FROM orders 
        WHERE payment_status = 'paid'
        GROUP BY DATE(order_date) 
        ORDER BY date ASC";

$result = $conn->query($sql);

$sales_data = [];
while ($row = $result->fetch_assoc()) {
    $sales_data[] = $row;
}

echo json_encode($sales_data);
?>
